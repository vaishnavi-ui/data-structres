#include<stdio.h>
int c;
void main()
{
int n,i,arr[1000],small,large,dno,j,ch;
printf("Enter the size of the array: ");
scanf("%d",&n);
printf("\nEnter the array: ");
for(i=0;i<n;i++)
scanf("%d",&arr[i]);
do
{printf("\nmake a choice.1.print array.2.find smallest and largest no.3.delete numbers.4.exit ");
scanf("%d",&c);
switch(c)
{
case 1:
printf("The elements of the array :");
for(i=0;i<n;i++)
printf("\nElement %d: %d",(i+1),arr[i]);
break;
case 2:
    small=arr[0];
    large=arr[0];
for(i=0;i<n;i++)
{
if(arr[i]<=small)
small=arr[i];
if(arr[i]>=large)
large=arr[i];
}
printf("\nThe smallest number in the array is: %d", small);
printf("\nThe largest number in the array is : %d",large);
break;
case 3:
del(arr,n);
}
}while(c!=4);
}
void del(int arr[1000],int n )
{   int dno,j,i,ch;
do
  {
 printf("\nEnter the index number of element which you want to delete: ");
    scanf("%d",&dno);
     dno--;
    if(dno>n)
    {        printf("This element does not exist");
        continue;
    }
for(j=dno;j<n-1;j++)
   {
       arr[j]=arr[j+1];
   }
printf("The new array is: ");
for(i=0;i<n-1;i++)
    printf("\n%d",arr[i]);
    printf("do you wish to continue?yes=3,no=0");
    scanf("%d",&c);
}while(c==3);
}
