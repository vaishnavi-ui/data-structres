#include<iostream>
#include<string.h>
using namespace std;
struct student{
 int rno;
 string name;
 char grade;
 };
int main()
{ int n; char ch;
 struct student s[500];
 void particular_student(struct student[],int);
 cout<<"Enter the number of student: ";
 cin>>n;
 for(int i=0;i<n;i++)
 { cout<<"Stduent "<<i+1<<endl;
 cout<< "Enter the name: ";
 cin>>s[i].name;
 cout<<"Enter the roll number: ";
 cin>>s[i].rno;
 cout<<"Enter the grade: ";
 cin>>s[i].grade;
}
cout<<endl;
cout<<"The details of all the students are: "<<endl;
for(int i=0;i<n;i++)
{cout<<"Stduent "<<i+1<<endl;
cout<<"Name: "<<s[i].name<<endl;
cout<<"Roll No.: "<<s[i].rno<<endl;
cout<<"Grade: "<<s[i].grade<<endl;
}
cout<<endl;
for(;;)
{
    cout<<"Do you want to print the details of a specific student? Enter y or n: ";
cin>>ch;
if(ch=='y')
   particular_student(s,n);
   else
    break;
}
}
void particular_student(struct student s[500],int n)
{ int ch,printdetails,roll,check; string stdname;
cout<<"If you want to search using roll no. enter 1 or to search using name enter 2: ";
cin>>ch;
if(ch==1||ch==2)
{
if(ch==1)
{
cout<<"Enter the roll no. of the student: ";
cin>>roll;
for(int i=0;i<n;i++)
{
if(s[i].rno==roll)
{
printdetails=i;
check=1;
break;
}
}
if(check!=1)
    cout<<"Roll No. does not exist"<<endl;
}
else if(ch==2)
{
cout<<"Enter the name of the student: ";
cin>>stdname;
for(int i=0;i<n;i++)
{
if(stdname==s[i].name)
{
printdetails=i;
check=1;
break;
}
}
if(check!=1)
    cout<<"Name does not exist!"<<endl;
}
if(check==1)
{
cout<<endl;
cout<<"The details of the student are: "<<endl;
cout<<"Name: "<<s[printdetails].name<<endl;
cout<<"Roll No.: "<<s[printdetails].rno<<endl;
cout<<"Grade: "<<s[printdetails].grade<<endl;
}
}
else
    cout<<"Enter a valid choice";
}
