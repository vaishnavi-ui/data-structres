#include<iostream>
using namespace std;
void move(int n,char s,char d,char t)
{
    if(n==1)
    {
        cout<<"Move ring from "<<s<<" to "<<d<<endl;
    }

    else
    {
        move(n-1,s,t,d);
        move(1,s,d,t);
        move(n-1,t,d,s);
    }
}

int main()
{
    int n;
    cout<<"Enter number of rings"<<endl;
    cin>>n;

    move(n,'A','C','B');
    return 0;
}
