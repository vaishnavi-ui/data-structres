#include<iostream>
#include<cstring>
//#include<math.h>
using namespace std;
char a[20],b[20];
int i,len,h,k=0;
void push(char);
int pop(void);
int compare(char,char);
int main()
{
    int choice;
    char x;
    do
    {k=0;
    h=0;
    cout<<"enter the expression"<<endl;
    cin>>a;
    len=strlen(a);
    for(i=0;i<len;i++)
    {h=compare(x,a[i]);
        switch(a[i])
        {
        case '{':
            push(a[i]);
            break;
        case '(':
            push(a[i]);
            break;
        case '[':
            push(a[i]);
            break;
        case '}':
            x=pop();
            h=compare(x,a[i]);
            break;
        case ')':
            x=pop();
            h=compare(x,a[i]);
            break;
        case ']':
            x=pop();
            h=compare(x,a[i]);
            break;
        default:
            continue;
        }
    }
    if(k==0&&h==0)
            cout<<"the parenthesis is balanced"<<endl;
        else
            cout<<"the parenthesis is not balanced"<<endl;
    cout<<"do you wish to continue?1=yes,0=no"<<endl;
    cin>>choice;
    }while(choice==1);
    return 0;
}
void push(char c)
{
       b[k]=c;
       h++;
        k++;
}
int pop()
{
        k--;
        return b[k];
}
int compare(char y,char z)
{
    if(y=='}')
    {
        if(z=='{')
            h--;
    }
    else if(y==')')
    {
        if(z=='(')
            h--;
    }
    else if(y==']')
    {
        if(z=='[')
            h--;
    }
    return h;
}
