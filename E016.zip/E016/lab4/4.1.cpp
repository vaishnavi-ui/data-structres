#include<iostream>
using namespace std;
int n;
int fr=-1,rear=-1;
int q[10];
void isFull()
{
    cout<<"queue is full"<<endl;
}
void isEmpty()
{
    cout<<"queue is  empty"<<endl;
}
void enqueue()
{
     if(fr==-1&&rear==-1)
    {
       fr=0;
       rear=0;
    cin>>q[rear];
    //rear=(rear+1)%n;
    }
    else if((rear==(fr-1)%n-1)||(fr==0&&rear==n-1))
    {
        isFull();
    }
    else
    {
    rear=(rear+1)%n;
        cin>>q[rear];
    }
}
void dequeue()
{
    if(fr==-1&&rear==-1)
    {
        isEmpty();
    }
    if(fr==rear)
    {
        cout<<q[fr]<<endl;
        q[fr]=0;
         fr=-1,rear=-1;
    }
    else
    {
        cout<<q[fr]<<endl;
        q[fr]=0;
        fr=(fr+1)%n;
    }
}
void display()
{
    if(rear==-1&&fr==-1)
    {
        isEmpty();
    }
    else
    {
        if(rear>=fr)
        {
            for(int i=fr;i<=rear;i++)
            {
                cout<<q[i]<<endl;
            }
        }
        else
        {
            for(int i=fr;i<n;i++)
            {
                cout<<q[i]<<endl;
            }
            for(int i=0;i<=rear;i++)
            {
                cout<<q[i]<<endl;
            }
        }
    }
}
int  main()
{
    int ch,c;
    cout<<"enter size of array"<<endl;
    cin>>n;
    do
    {
        cout<<"make a choice.1.queue empty?.2.queue full?.3.enqueue.4.dequeue.5.display"<<endl;
        cin>>c;
        switch(c)
        {
        case 1:
            isEmpty();
            break;
        case 2:
            isFull();
            break;
        case 3:
           enqueue();
           break;
        case 4:
            dequeue();
            break;
        case 5:
            display();
            break;
        default:
            cout<<"wrong input"<<endl;
        }
        cout<<"do you wish to continue?1=yes,0=no"<<endl;
        cin>>ch;
    }while(ch!=0);
}
