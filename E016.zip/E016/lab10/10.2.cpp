#include<iostream>
using namespace std;
void linear(void);
void binary(void);
int n;
int a[20];
int main()
{
    int c;
    do{
        c=0;
    cout<<"enter size of array"<<endl;
    cin>>n;
    cout<<"enter array elements"<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<"enter marks for student:"<<i+1<<" ";
        cin>>a[i];
        cout<<endl;
    }
    cout<<"make a choice.1.linear search.2.binary search.3.exit"<<endl;
    cin>>c;
    switch(c)
    {
    case 1:
        linear();
        break;
    case 2:
        binary();
        break;
    case 3:
        break;
    default:
        cout<<"wrong input"<<endl;
    }
    }while(c!=3);
}
void linear()
{
    int b,k=0;
    cout<<"enter student marks to be searched:";
    cin>>b;
    for(int i=0;i<n;i++)
        {
            if(a[i]==b)
            {
                k++;
            }
        }
        if(k!=0)
        {
            cout<<"Student Number found"<<endl;
        }
        else
        {
            cout<<"Student Number not found"<<endl;
        }
}
void binary()
{
    int num,k;
    cout<<"enter student marks to be searched"<<endl;
    cin>>num;
    int lb=0; int ub=n;
       while(ub>=lb)
       {
           int m=(lb+ub)/2;
           if(a[m]==num)
           {
               k++;
               break;
            }
            else if(a[m]<num)
            {
                lb=m+1;
            }
            else
            ub=m-1;
        }
       if(k!=0)
        {
            cout<<"Student Number found"<<endl;
        }
        else
        {
            cout<<"Student Number not found"<<endl;
        }
}
