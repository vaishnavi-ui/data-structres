#include<iostream>
using namespace std;
void mergeSort(int,int);
void Merge(int,int,int);
void insertion(void);
void selection(void);
int n;
int a[20];
int main()
{
    int c;
    do{
        c=0;
    cout<<"enter size of array"<<endl;
    cin>>n;
    cout<<"enter array elements"<<endl;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    cout<<"make a choice.1.merge sort.2.insertion sort.3.selection sort.4.exit."<<endl;
    cin>>c;
    switch(c)
    {
    case 1:
        mergeSort(0,n-1);
        cout<<"the merge sort array is:";
        for(int i=0;i<n;i++)
        {
            cout<<a[i]<<"\t";
        }
        break;
    case 2:
        insertion();
        break;
    case 3:
        selection();
        break;
    case 4:
        break;
    default:
        cout<<"wrong input"<<endl;
    }
    }while(c!=4);
}
void mergeSort(int low,int high)
{
    if(low<high)
    {
        int mid=(low+high)/2;
        mergeSort(low,mid);
        mergeSort(mid+1,high);
        Merge(low,mid,high);
    }
}
void Merge(int low,int mid,int high)
{
    int i,j,k,temp[high-low+1];
 i=low;
 k=0;
 j=mid+1;
 while (i<=mid&&j<=high)
 {
  if (a[i]<a[j])
  {
   temp[k]=a[i];
   k++;
   i++;
  }
  else
  {
   temp[k]=a[j];
   k++;
   j++;
  }
 }
 while (i<=mid)
 {
  temp[k]=a[i];
  k++;
  i++;
 }
 while (j<=high)
 {
  temp[k]=a[j];
  k++;
  j++;
 }
 for (i=low;i<=high;i++)
 {
  a[i]=temp[i-low];
 }
}
void insertion()
{
    int i,j,newvalue;
    for(i=1;i<n;i++)
        {
            newvalue=a[i];
            j=i;
            while(j>0&&newvalue<a[j-1])
            {
                a[j]=a[j-1];
                j=j-1;
            }
            a[j]=newvalue;
        }
        cout<<"the insertion sorted array is:";
        for(i=0;i<n;i++)
        {
            cout<<a[i]<<"\t";
        }
}
void selection()
{
    int i,j,temp,m;
    for(i=0;i<n-1;i++)
        {
            m=i;
            for(j=i+1;j<n;j++)
            {
                if(a[m]>a[j])
                {
                    m=j;
                }
            }
            temp=a[i];
            a[i]=a[m];
            a[m]=temp;
        }
        cout<<"the selection sorted array is:";
        for(i=0;i<n;i++)
        {
            cout<<a[i]<<"\t";
        }
}

