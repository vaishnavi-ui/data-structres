#include<iostream>
//#include<stdio.h>
using namespace std;
void push(void);
void pop(void);
void display(void);
void isFull(void);
void isEmpty(void);
int top=-1;int n;
int a[10];
int main()
{
  int c,ch;
  cout<<"enter size of array";
  cin>>n;

  do
  {

      cout<<"make a choice"<<endl<<"1.push"<<endl<<"2.pop"<<endl<<"3.display"<<endl<<"4.empty"<<endl<<"5.full"<<endl;
      cin>>c;
      switch(c)
      {
      case 1:
        push();
        break;
      case 2:
        pop();
        break;
      case 3:
        display();
        break;
      case 4:
        isEmpty();
        break;
      case 5:
        isFull();
        break;
      default:
        cout<<"wrong input"<<endl;
      }
      cout<<"do you wish to continue?"<<endl<<"1=yes,0=no";
      cin>>ch;
  }while(ch==1);
}
void pop()
{
    if(top==-1)
    {
        cout<<"stack underflow"<<endl;
    }
    else
        {cout<<a[top];
    top--;
        }
}
void push()
{
    if(top==n-1)
    {
        cout<<"stack overflow"<<endl;
    }
    else
       { top++;
    cin>>a[top];
       }
}
void display()
{
    int i;
    cout<<"array is:";
    for(i=top;i>=0;i--)
    {
        cout<<a[i];
        cout<<""<<endl<<"";
    }
}
void isFull()
{
    if(top==n-1)
    {
        cout<<"stack is full"<<endl;
    }
    else
        cout<<"stack is not full"<<endl;
}
void isEmpty()
{
    if(top==-1)
    {
        cout<<"stack is empty"<<endl;
    }
    else
        cout<<"stack is not empty"<<endl;
}
