#include<iostream>
#include<cstring>
using namespace std;
int top=-1,n,val; char arr[100]; int exp[100],a,b;
int main()
{int i,c;
int push(int);
int pop(); //peep();
void display(int);
cout<<"Exp: ";
cin>>arr;
n=strlen(arr);
for(i=0;i<n;i++)
{
switch(arr[i])
{
    case '+':
        a=pop();
        b=pop();
        val=b+a;
        push(val);
        break;
    case '-':
        a=pop();
        b=pop();
        val=b-a;
        push(val);
        break;
    case '*':
        a=pop();
        b=pop();
        val=b*a;
        push(val);
        break;
    case'/':
        a=pop();
        b=pop();
        val=b/a;
        push(val);
        break;
    case'^':
        val=1;
        a=pop();
                  b=pop();
        for(c=1;c<=a;c++)
        {
            val*=b;
        }
        push(val);
        break;
    default:
        int send=arr[i]-'0';//casting
        push(send);
}
} cout<<"The value of the expression is: "<<exp[0];}
int push(int num)
{     if(top<n)
    {
        top++;
        exp[top]=num;
    }
}
int pop()
{int val;
    val= exp[top];
    exp[top]=0;
    top--;
    return val;
}
void display(int i)
{int a;
for(a=0;a<=i;a++)
cout<<exp[a]<<"  ";
cout<<"over"<<" "<<endl;}
