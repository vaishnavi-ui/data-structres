#include<iostream>
using namespace std;
void insertBeginning(int);
void insertEnd(int);
void insertMiddle(int);
void createLinkedlist(struct node);
void traverse(void);
void modify(int);
void Delete(void);
struct node
{
  int data;
  struct node* next;
};
node *head=NULL;
node *head1=NULL;
node *head2=NULL;
void insertBeginning(int val)
{
    node *add=new node;
    add->data=val;
    add->next=head;
    head=add;
}
void insertEnd(int val)
{
    if(head==NULL)
    {
        cout<<"linked list is empty"<<endl;
    }
     node *add=new node;
     add->data=val;
     node *temp;
     temp=head;
     while(temp->next!=NULL)
     {
         temp=temp->next;
     }
     temp->next=add;
     add->next=NULL;
}
void insertMiddle(int val)
{
    if(head==NULL)
    {
        cout<<"linked list is empty"<<endl;
    }
    else
    {int p,i;
    cout<<"enter position to be entered at"<<endl;
    cin>>p;
    node *add=new node;
    node *temp;
    temp=head;
    if(p==1)
    {
        insertBeginning(p);
    }
    else
    {
    while(p>2)
    {
        temp=temp->next;
        p--;
    }
    add->data=val;
    add->next=temp->next;
    temp->next=add;
    }
    }
}
void createLinkedlist(node *head)
{
    int i,n,val;
    cout<<"enter no of nodes required"<<endl;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cout<<"enter value to be added"<<endl;
        cin>>val;
        insertBeginning(val);
    }
}
void traverse()
{
    node *temp;
    temp=head;
    if(temp==NULL)
    {
        cout<<"linked list is empty"<<endl;
    }
    else
    {while(temp!=NULL)
    {
        cout<<temp->data<<endl;
        temp=temp->next;
    }
    }
}
void modify(int val)
{
    if(head==NULL)
    {
        cout<<"linked list is empty"<<endl;
    }
    else
    {node *temp;
    temp=head;
    int p;
    cout<<"enter position to be modified at";
    cin>>p;
    while(p!=0)
    {
        temp=temp->next;
        p--;
    }
    temp->data=val;
    }
}
void Delete()
{
    if(head==NULL)
    {
        cout<<"empty"<<endl;
    }
    else
     {node *temp=head;
     node *temp2;
     node *temp3;
    int p;
    cout<<"enter position to be deleted at";
    cin>>p;
     if(p==1)
     {
         head=head->next;
     }
     else
     {
         while(p>1)
         {
             temp2=temp;
             temp=temp->next;

             p--;
         }
         temp3=temp->next;
         temp2->next=temp3;
     }
     delete temp;
     }
}
void concat()
{
    node *temp=head1;
    while(temp!=NULL)
    {
        temp=temp->next;
    }
    temp=head2;
}
int main()
{
    int val;
   // head=NULL;
    int c;
    do
    {cout<<"make a choice0.EXIT.1.insert node at beginning.2.insert node at end.3.insert node at middle.4.create linked list.5.traverse list.6.modify info.7.delete.8.concat";
    cin>>c;
    switch(c)
    {
    case 0:
        break;

    case 1:
        cout<<"enter number"<<endl;
        cin>>val;
        insertBeginning(val);
        break;
    case 2:
        cout<<"enter number"<<endl;
        cin>>val;
        insertEnd(val);
        break;
    case 3:
        cout<<"enter number"<<endl;
        cin>>val;
        insertMiddle(val);
        break;
    case 4:
        createLinkedlist(head);
        break;
    case 5:
        traverse();
        break;
    case 6:
        cout<<"enter number"<<endl;
        cin>>val;
        modify(val);
        break;
    case 7:
        Delete();
        break;
    case 8:
        head1=NULL;
        createLinkedlist(head1);
        createLinkedlist(head2);
        concat();
        break;
    default:
        cout<<"wrong input"<<endl;
    }
    }while(c!=0);
}
