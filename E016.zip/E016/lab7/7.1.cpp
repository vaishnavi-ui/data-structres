#include<iostream>
using namespace std;
struct node
{
    int data;
    struct node *next;
};
node *head=NULL;
int k;
void insertBeg(int val)
{
    node *add=new node;
    node *temp=head;
    if(head==NULL)
    {
        add->data=val;
        k++;
        add->next=add;
        head=add;
    }
    else
    {
        add->data=val;
        k++;
        add->next=head;
        while(temp->next!=head)
        {
            temp=temp->next;
        }
        temp->next=add;
        head=add;
    }
}
void insertEnd(int val)
{
    node *temp;
    temp=head;
    node* add=new node;
    if(head==NULL)
    {
        add->data=val;
        k++;
        add->next=add;
        head=add;
    }
    else{
        add->data=val;
        k++;
        while(temp->next!=head)
        {
            temp=temp->next;
        }
        temp->next=add;
        add->next=head;
    }
}
void insertMiddle(int val)
{
    node *temp=head;
    node *temp1;
     int p;
    cout<<"enter position to insert element";
    cin>>p;
    if(p==1)
    {
        insertBeg(val);
    }
    else if(p>1&&p<k)
    {
        while(p!=1)
        {
            temp1=temp;
            temp=temp->next;
            p--;
        }
        node *add=new node();
        add->data=val;
        k++;
        temp1->next=add;
        add->next=temp;
    }
    else if(p==k)
    {
        insertEnd(val);
    }
    else
    {
        cout<<"the position doesnt exist"<<endl;
    }
}
void createLinkedlist()
{
    int p,val,i;
    cout<<"enter the number of nodes to be inserted"<<endl;
    cin>>p;
    for(i=0;i<p;i++)
    {
        cout<<"enter value";
        cin>>val;
        insertBeg(val);
    }
}
void deleteBeg()
{
    node *temp=head;
    head=head->next;
    temp=NULL;
    delete temp;
    k--;
}
void deleteEnd()
{
    node *t=head;
    node *temp=head;
    while(temp->next!=head)
    {
        t=temp;
        temp=temp->next;
    }
    temp=NULL;
    t->next=head;
    delete temp;
    k--;
}
void deleteP()
{
    node *temp=head;
    node *t=new node;
    int p;
    cout<<"enter position to delete";
    cin>>p;
    if(p==1)
    {
        deleteBeg();
    }
    else if(p>1&&p<k)
    {
        while(p!=1)
        {
            t=temp;
            temp=temp->next;
            p--;
        }
        t->next=temp->next;
        delete temp;
        k--;
    }
    else if(p==k)
    {
        deleteEnd();
    }
    else
    {
        cout<<"position doesn't exist"<<endl;
    }
}
void display()
{
    node *temp=head;
    if(head==NULL)
    {
        cout<<"empty linked list"<<endl;
    }
    else {
   while(temp->next!=head)
        {cout<<temp->data<<endl;
        temp=temp->next;
    }
    cout<<temp->data<<endl;
    }
}
int main()
{
    int val;
    int c;
    do
    {
        cout<<"make a choice\n1.insert beginning\n2.insert middle\n3.insert end\n4.delete beginning\n5.delete end\n6.delete middle\n7.display\n8.create link list\n0.EXIT";
        cin>>c;
        switch(c)
        {
        case 0:
            break;
        case 1:
            cout<<"enter element";
            cin>>val;
            insertBeg(val);
            break;

        case 2:
            cout<<"enter element";
            cin>>val;
            insertMiddle(val);
            break;

          case 3:
              cout<<"enter element";
            cin>>val;
            insertEnd(val);
            break;

            case 4:
                deleteBeg();
            break;

            case 5:
                 deleteEnd();
            break;

            case 6:
                 deleteP();
            break;

            case 7:
                display();
            break;

            case 8:
                createLinkedlist();
                break;
            default:
                cout<<"wrong input"<<endl;
                break;
        }
    }while(c!=0);
}
