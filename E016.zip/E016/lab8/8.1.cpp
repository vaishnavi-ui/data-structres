#include<iostream>
using namespace std;
int n1=0,n2;
struct node
{
int data;
struct node* left;
struct node* right;
};
node* deletenode(node* root,int val);
node* insert(node* root,int val)
{
    if(root==NULL)
    {
        node* n=new node();
        n->data=val;
        n->left=NULL;
        n->right=NULL;
        root=n;
    }
    else if(val<root->data)
        root->left=insert(root->left,val);
    else if(val>root->data)
        root->right=insert(root->right,val);
    else
        cout<<"Duplicate Value"<<endl;
    return root;
}


void inorder(node* root)
{
    if(root==NULL)
        return;
    inorder(root->left);
    cout<<root->data<<endl;
    inorder(root->right);
}


node* min(node* root)
{
    while(root->left!=NULL)
        root=root->left;
    return root;
}


node* delroot(node* root,int val)
{
    if(root->left==NULL&&root->right==NULL)
    {
        root=NULL;
        delete root;
    }
    else if(root->left==NULL)
    {
        node* temp=root;
        root=root->right;
        delete temp;
    }
    else if(root->right==NULL)
    {
        node* temp=root;
        root=root->left;
        delete temp;
    }
    else
    {
        node* temp=min(root->right);
        root->data=temp->data;
        root->right=deletenode(root->right, temp->data);
    }
    return root;
}


node* deletenode(node* root, int val)
{
     if(root==NULL)
        cout<<"Empty"<<endl;
     else if(val==root->data)
     {
         root=delroot(root, val);
         return root;
     }
     else if(val<root->data)
     {
         root->left=deletenode(root->left,val);
     }
     else
        root->right=deletenode(root->right,val);
     return root;
}

int main()
{
    int x=0,e=1;
    node* root=NULL;
    do{
        cout<<"make a choice\n0.exit"<<endl;
        cout<<"1.add a node"<<endl;
        cout<<"2.delete a node"<<endl;
        cout<<"3.display"<<endl;
        int pos;
        cout<<endl;
        cin>>x;
        switch(x)
        {
        case 0:
            break;
        case 1:
            int val;
            cout<<"Enter Value To Enter"<<endl;
            cin>>val;
            root=insert(root,val);
            break;
        case 2:
            cout<<"Enter Value To Delete"<<endl;
            cin>>val;
            root=deletenode(root,val);
            break;
        case 3:
             inorder(root);
            break;

       }
    }while(e!=0);
}

