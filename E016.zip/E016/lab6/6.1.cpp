#include<iostream>
using namespace std;
void insertBeginning(int);
void insertEnd(int);
void insertMiddle(int);
void createLinkedlist(void);
void traverseForward(void);
void traverseBackward(void);
void Delete(void);
int k=0;
struct node
{
    struct node *prev;
    int data;
    struct node *next;
};
node *head=NULL;
void insertBeginning(int val)
{
    node *temp=head;
    if(temp==NULL)
   {
        node *add=new node;
        add->data=val;
        add->prev=NULL;
        add->next=NULL;
        head=add;
   }
   else
   {
        node *add=new node;
        add->data=val;
        add->prev=NULL;
        add->next=head;
        head->prev=add;
        head=add;
   }

}
void insertEnd(int val)
{
    node *temp=head;

    node *add=new node;
    if(temp==NULL)
    {
        add->data=val;
        add->prev=NULL;
        add->next=NULL;
        head=add;
    }
    else
    {
        while(temp->next!=NULL)
        {
            temp=temp->next;
        }
        temp->next=add;
        add->data=val;
        add->prev=temp;
        add->next=NULL;
    }
}
void insertMiddle(int val)
{
    node *temp2;
    if(head==NULL)
    {
        cout<<"linked list is empty"<<endl;
    }
    else
    {int p,i;
    cout<<"enter position to be entered at"<<endl;
    cin>>p;
    node *add=new node;
    node *temp;
    temp=head;
    if(p==1)
    {
        insertBeginning(val);
    }
    else
    {
    while(p>2)
    {
        temp=temp->next;
        p--;
    }
    temp2=temp->next;
    temp->next=add;
    temp2->prev=add;
    add->next=temp2;
    add->prev=temp;
    add->data=val;
    }
    }
}

void createLinkedlist()
{
    int i,n,val;
    cout<<"enter no of nodes required"<<endl;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cout<<"enter value to be added"<<endl;
        cin>>val;
        k++;
        insertBeginning(val);
    }
}
void traverseForward()
{
    node *temp=head;
    if(temp==NULL)
    {
        cout<<"empty"<<endl;
    }
    else{
        while(temp!=NULL)
        {
            cout<<temp->data<<endl;
            temp=temp->next;
        }
    }
}
void traverseBackward()
{
    node *temp=head;
    if(temp==NULL)
    {
        cout<<"empty"<<endl;
    }
    else if(head->next==NULL&&head->prev==NULL)
   {
    cout<<head->data<<endl;
   }
    else {
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    while(temp!=NULL)
    {
        cout<<temp->data<<endl;
        temp=temp->prev;
    }
    }
}
void Delete()
{
    if(head==NULL)
    {
        cout<<"empty"<<endl;
    }
    else
     {node *temp;
     node *temp1;
     node *temp2;
    int p;
    cout<<"enter position to be deleted at";
    cin>>p;
     if(p==1)
     {
         if(k==1)
         {
           temp=head;
           head->next=NULL;
           head->prev=NULL;
           delete temp;
           k--;
         }
         else {
         temp=head;
         head=head->next;
         head->prev=NULL;
         delete temp;
         k--;
         }
     }
     else
     {
         if(p<k){
                temp1=head;
         temp2=head->next;
         while(p!=1)
         {
             temp=temp1;
             temp1=temp2;
             temp2=temp2->next;
             p--;
         }
        temp->next=temp2;
        temp2->prev=temp;
        delete temp1;
        k--;
     }
     else if(p==k)
     {
         temp=head;
         temp1=head->next;
         while(temp1->next!=NULL)
         {
             temp1=temp1->next;
             temp=temp->next;
         }
         temp->next=NULL;
         temp1->prev=NULL;
         delete temp1;
         k--;
     }
     else
     {
         cout<<"position doesn't exist"<<endl;
     }
     }
     }
}
int main()
{
    int val;
   head=NULL;
    int c;
    do
    {cout<<"make a choice\n0.EXIT.\n1.insert node at beginning.\n2.insert node at end.\n3.insert node at middle.\n4.create linked list.\n5.traverse list forward.\n6.traverse list backward.\n7.delete a node.";
    cin>>c;
    switch(c)
    {
    case 0:
        break;

    case 1:
        cout<<"enter value to be added at beginning"<<endl;
        cin>>val;
        k++;
        insertBeginning(val);
        break;
    case 2:
        cout<<"enter value to be added at end"<<endl;
        cin>>val;
        k++;
        insertEnd(val);
        break;
    case 3:
        cout<<"enter value to be added at middle"<<endl;
        cin>>val;
        k++;
        insertMiddle(val);
        break;
    case 4:
        createLinkedlist();
        break;
    case 5:
        traverseForward();
        break;
    case 6:
        traverseBackward();
        break;
    case 7:
        Delete();
        break;
    default:
        cout<<"wrong input";
    }
    }while(c!=0);
    return 0;
}
