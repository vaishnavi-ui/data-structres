#include<bits/stdc++.h>
#include <iostream>

using namespace std;

void addEdge(vector<int> adj[], int u, int v)
{
    adj[u].push_back(v);
    adj[v].push_back(u);
}

void DFSUtil(int u, vector<int> adj[],
                    vector<bool> &visited)
{
    visited[u] = true;
    cout << u << " ";
    for (int i=0; i<adj[u].size(); i++)
        if (visited[adj[u][i]] == false)
            DFSUtil(adj[u][i], adj, visited);
}


void DFS(vector<int> adj[], int V)
{
    vector<bool> visited(V, false);
    for (int u=0; u<V; u++)
        if (visited[u] == false)
            DFSUtil(u, adj, visited);
}

int main()
{
    int V,ch,i,j;
    cout<<"enter number of vertices"<<endl;
    cin>>V;
    vector<int> adj[V];

   cout<<"Enter 1 if you want an edge and 0 if you do not want it"<<endl;
   for(i=0;i<V;i++)
   {
       for(j=i+1;j<V;j++)
       {
           cout<<"Edge from "<<i<<" to "<<j<<" : ";
           cin>>ch;

           if(ch!=0)
           addEdge(adj, i, j);


       }
   }
    cout<<"DFS : "<<endl;
    DFS(adj, V);

    return 0;
}

