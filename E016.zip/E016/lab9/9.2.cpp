#include <bits/stdc++.h>
#define pb push_back

using namespace std;

vector<bool> v;
vector<vector<int> > graph;

void edge(int a, int b)
{
    graph[a].pb(b);


}

void bfs(int u)
{
    queue<int> q;

    q.push(u);
    v[u] = true;

    while (!q.empty()) {

        int f = q.front();
        q.pop();

        cout << f << " ";


        for (auto i = graph[f].begin(); i != graph[f].end(); i++) {
            if (!v[*i]) {
                q.push(*i);
                v[*i] = true;
            }
        }
    }
}


int main()
{
    int n, e;
    cout<<"Enter number of vertices and edges"<<endl;
    cin >> n >> e;

    v.assign(n, false);
    graph.assign(n, vector<int>());

    int a, b;
    cout<<"Enter edges"<<endl;
    for (int i = 0; i < e; i++) {
        cin >> a >> b;
        edge(a, b);
    }

    cout<<"BFS :"<<endl;

    for (int i = 0; i < n; i++) {
        if (!v[i])
            bfs(i);
    }

    return 0;
}

